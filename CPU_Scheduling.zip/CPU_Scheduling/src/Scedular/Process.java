package Scedular;

public class Process {
	
	private String name;
	private int burstTime;
	private int arrivalTime;
	private int priority;
	private double quantum;
	private int nonPree = 0;
	private int pree = 0;
	public Process() {}
	
	public Process(String name, int burstTime , int arrivalTime, int priority, double quantum) {
		this.name = name;
		this.burstTime = burstTime;
		this.arrivalTime = arrivalTime;
		this.priority = priority;
		this.quantum = quantum;
		
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getName() {
		return this.name;
	}
	
	public void setBurstTime(int burstTime) {
		this.burstTime = burstTime;
	}
	
	public int getBurstTime() {
		return this.burstTime;
	}
	
	public void setArrivalTime(int arrivalTime) {
		this.arrivalTime = arrivalTime;
	}
	
	public int getArrivalTime() {
		return this.arrivalTime;
	}
	
	public void setPriority(int priority) {
		this.priority = priority;
	}
	
	public int getPriority() {
		return this.priority;
	}
	
	public void setQuantum(double quantum) {
		this.quantum = quantum;
	}
	
	public double getQuantum() {
		return this.quantum;
	}
	
	
	public void setPree(int pree) {
		this.pree = pree;
	}
	
	public int getPree() {
		return this.pree;
	}
	
	public void setNonPree(int nonPree) {
		this.nonPree = nonPree;
	}
	
	public int getNonPree() {
		return this.nonPree;
	}
}
