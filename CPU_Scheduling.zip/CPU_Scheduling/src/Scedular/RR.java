package Scedular;

import java.util.*;
public class RR {
    int quantam,index=0,fin=0,q,number_of_processes,first=0,context,min;
    double average_wait=0,average_turnaround=0;
    boolean flag =true,check=true;
    public void run(){
        Scanner cin = new Scanner(System.in);
        System.out.print("\nEnter the time quanta : ");
        quantam = cin.nextInt();
        q=quantam;
        System.out.print("\nEnter the time of context switching : ");
        context = cin.nextInt();
        System.out.print("\nEnter the number of processes : ");
        number_of_processes = cin.nextInt();
        int[] arrival = new int[number_of_processes];
        int[] burst = new int[number_of_processes];
        int[] temp_burst = new int[number_of_processes];
        int[] end = new int[number_of_processes];
        int[] wait = new int[number_of_processes];
        int[] temp = new int[number_of_processes];
        int[] store=new int[number_of_processes];
        int[] complete=new int[number_of_processes];
        int[] t_complete=new int[number_of_processes];
        int timer=0;
        for(int i=0;i<number_of_processes;i++){
            wait[i]=0;
            end[i]=0;
            store[i]=0;
            temp[i]=0;
            
        }
        System.out.print("\nEnter the arrival time of the processes : ");
        for(int i = 0; i < number_of_processes; i++)
            arrival[i] = cin.nextInt();

        System.out.print("\nEnter the burst time of the processes : ");
        for(int i = 0; i < number_of_processes; i++){
            burst[i] = cin.nextInt();
            temp_burst[i]=burst[i];
        }
        while(flag){
            for(int i=0;i<number_of_processes ;i++){
                quantam=q;
                while(quantam!=0 && temp_burst[i]!=0){
                    quantam--;
                    temp_burst[i]--;
                    timer++;
                    if(quantam<=0||temp_burst[i]<=0){
                        break;
                    }
                    
                }

                if(temp_burst[i]!=0 || quantam<q)
                    {
                        timer += context;
                    }
                    
            
                complete[i]= timer;
                for (int j = 0; j < complete.length; j++) {
                    t_complete[i]=complete[i];
                }
                

                if(first != timer){
                    System.out.println(first+" p"+(i+1)+" "+timer);
                }
                first=timer;
                
                int z=0;
                for(int k=i+1;k<number_of_processes;k++){
                    if(arrival[k]<=first){
                        temp[z]=k;
                        z++;
                    }
                }
                index=temp[0];
                int minmum=arrival[temp[0]];
                for(int j=0;j<temp.length;j++){
                    if(arrival[temp[j]]<minmum ){
                        minmum=arrival[temp[j]];
                        index=temp[j];
                    }
                }
            }
            for(int i=0;i<number_of_processes;i++)
            {
                if(temp_burst[i]!=0){
                    flag=true;
                    break;
                }
                flag=false;
            }
        }
        for(int i = 0; i < number_of_processes; i++){
            end[i] = complete[i] - arrival[i];
            wait[i] = end[i] - burst[i];
        }
        System.out.print("\nProgram No.\tArrival Time\tBurst Time\tComplete Time\tWait Time\tTurnAround Time"+"\n");
        for(int i = 0; i < number_of_processes; i++){
            System.out.print(i+1+"\t"+arrival[i]+"\t"+burst[i]+"\t"+t_complete[i]+"\t"+wait[i]+"\t"+end[i]+ "\n");
        }
        for(int i =0; i< number_of_processes; i++){
            average_wait += wait[i];
            average_turnaround += end[i];
        }
        System.out.print("\nAverage wait time : "+(average_wait/number_of_processes)
                +"\nAverage Turn Around Time : "+(average_turnaround/number_of_processes));
    }
}