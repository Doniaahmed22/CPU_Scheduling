package Scedular;

import java.util.Scanner;

public class NonPrimetive {
	
	public static void nonPreemptive(int NumberOfProcess , ReadyQueue queue) {
	  
	  for(int i = 1 ; i < NumberOfProcess; i++) {
			
			for(int j = 1; j < NumberOfProcess - 1; j++) {
				
				if(queue.getProcess(j).getBurstTime() > queue.getProcess(j+1).getBurstTime()) {
				
				String swapName = queue.getProcess(j).getName();
				int swapBurst = queue.getProcess(j).getBurstTime();
				int swapArrival = queue.getProcess(j).getArrivalTime();
			
				queue.getProcess(j).setName(queue.getProcess(j+1).getName());
				queue.getProcess(j).setBurstTime(queue.getProcess(j+1).getBurstTime());
				queue.getProcess(j).setArrivalTime(queue.getProcess(j+1).getArrivalTime());
			
				queue.getProcess(j+1).setName(swapName);
				queue.getProcess(j+1).setBurstTime(swapBurst);
				queue.getProcess(j+1).setArrivalTime(swapArrival);
				}
				
			}
	    }
	  
	    int startTime = 0;

	    queue.getProcess(0).setNonPree(0);
	    for(int i = 1 ; i < NumberOfProcess; i++) {
		  startTime+=queue.getProcess(i-1).getBurstTime();
		  queue.getProcess(i).setNonPree(startTime);
		  
	       }
	    }
	   
	  
	 public static void print(int NumberOfProcess , ReadyQueue queue) {
		 System.out.println("\n\n");
		    int sum = 0;
		 for(int i = 0 ; i < NumberOfProcess ; i++) {
			 System.out.print( queue.getProcess(i).getNonPree() +"|" + queue.getProcess(i).getName() + "|  ");
			 sum+= (queue.getProcess(i).getNonPree() - queue.getProcess(i).getArrivalTime());
		 }
		 
		System.out.println("  \n\nAverge waiting time = " + sum/NumberOfProcess);
		 
		 
	 }
	
	
	
public void run() {
		
		Scanner in = new Scanner(System.in);
		System.out.print("\n\nenter number of procees : ");
		int numberOfProcess = in.nextInt();
		
		ReadyQueue queue = new ReadyQueue(numberOfProcess);
		
		for(int i = 0 ; i < numberOfProcess ; i++) {
			
			System.out.print("\nenter name of procees " + (i+1) + " : ");
			String name = in.next();
			
			System.out.print("enter burst time of procees : ");
			int burst = in.nextInt();
			
			System.out.print("enter arrival time of procees : ");
			int arrival = in.nextInt();
			
			Process pro = new Process(name , burst , arrival, 0 ,0);
			
			queue.addProcess(pro);
		}
		
		System.out.println("\n\n\n\n Non Preemptive:");
		
		nonPreemptive(queue.getNumberOfProcess() , queue);
		
		print(queue.getNumberOfProcess() , queue);
		
	}

}
