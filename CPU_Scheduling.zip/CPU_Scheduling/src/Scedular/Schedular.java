package Scedular;

import java.util.Scanner;

public class Schedular {
	Schedular(){
		System.err.println("you choose AG Scheduling");
	}

	public static int isHighPriority(ReadyQueue ready, int Priority) {
		int i = 0;
		for(int j = 0 ; j < ready.getNumberOfProcess() ; j++) {
			if(Priority > ready.getProcess(j).getPriority()) {
				i = j;
			}
				
		}
		
		return i;
	}
	
	public static int isMiniBurst(ReadyQueue ready, int burst) {
		int i = 0; 
		for(int j = 0 ; j < ready.getNumberOfProcess() ; j++) {
			if(burst > ready.getProcess(j).getBurstTime()) {
				i = j;
			}
				
		}
		
		return i;
	}
	
	public static int getIndex(ReadyQueue ready, String name) {
		int i = 0;
		for( i = 0 ; i < ready.getNumberOfProcess() ; i++) {
			if(ready.getProcess(i).getName() == name)
				break;
		}
		return i;
	}
	
	
	
	public static ReadyQueue RemoveProscess(ReadyQueue ready , Process currentProcess , int Timer) {
		
		int index = getIndex(ready, currentProcess.getName());
		
		System.out.println("|" + currentProcess.getName() + "|"+Timer + "  ");
		
		for(int k =  index ; k < ready.getNumberOfProcess() - 1  ; k++) {
			ready.setProcess(ready.getProcess(k + 1), k);
		}
		
		int siz = ready.getNumberOfProcess();
		ready.setNumberOfProcess(--siz);
		return ready;
	}
	
	public static Process update(Process currentProcess , double Quantum ) {
		 double tempQuantum = currentProcess.getQuantum();
		 int tempBurst = currentProcess.getBurstTime();
		
		 currentProcess.setQuantum((tempQuantum - Quantum));
		 currentProcess.setBurstTime((tempBurst - (int)Quantum));
		 
		 return currentProcess;
	}
	
	public static ReadyQueue round(ReadyQueue ready, Process currentProcess) {
		int index = getIndex(ready, currentProcess.getName()); // 0
		for(int k = index ; k < ready.getNumberOfProcess() - 1 ; k++) {
			ready.setProcess(ready.getProcess(k + 1), k);
		}
		ready.setProcess(currentProcess, (ready.getNumberOfProcess() - 1));
		
		return ready;
		
	}
	
	public static Process betterBurstTime(Process currentProcess , double tempQuantum , int tempTimer) {
		
		tempQuantum = currentProcess.getQuantum();
		currentProcess.setQuantum((tempQuantum + tempTimer));
		
	    tempQuantum = currentProcess.getQuantum();
	    
	    double diff = tempQuantum - tempTimer;
	   
	    currentProcess.setQuantum(tempQuantum + diff);
		System.err.println("quantum = "+currentProcess.getQuantum());
	    return currentProcess;
	}
	
	public static Process betterPriority(Process currentProcess , double tempQuantum , int tempTimer) {
		
		tempQuantum = currentProcess.getQuantum();
		currentProcess.setQuantum((tempQuantum + tempTimer));
		
	    tempQuantum = currentProcess.getQuantum() - tempTimer;
		
		int x = (int) Math.ceil(tempQuantum/2);
	
		tempQuantum = currentProcess.getQuantum();
		
		currentProcess.setQuantum((tempQuantum + x ));

		System.err.println("quantum = "+currentProcess.getQuantum());

		return currentProcess;
	}
	
	
	public void run() {
		
		Scanner in = new Scanner(System.in);
		System.out.print("\n\nenter number of procees : ");
		int numberOfProcess = in.nextInt();
		
		ReadyQueue queue = new ReadyQueue(numberOfProcess);
		
		for(int i = 0 ; i < numberOfProcess ; i++) {
			
			System.out.print("\nenter name of procees " + (i+1) + " : ");
			String name = in.next();
			
			System.out.print("enter burst time of procees : ");
			int burst = in.nextInt();
			
			System.out.print("enter arrival time of procees : ");
			int arrival = in.nextInt();
			
			System.out.print("enter Priority of procees : ");
			int priority = in.nextInt();
			
			System.out.print("enter Priority of Quantum : ");
			int quantum = in.nextInt();
			
			Process pro = new Process(name , burst , arrival, priority , quantum);
			
			queue.addProcess(pro);
		}
		
		queue.sortArrival();
		int Timer = 0 , j = -1;
		int tempTimer = 0;
		ReadyQueue ready = new ReadyQueue(numberOfProcess);
		ready.addProcess(queue.getProcess(0));
	
		Process currentProcess = null;
		int i = 0;
		double tempQuantum = 0 ;
		int tempBurst;
		
		
		System.out.println("\n\n\n\nAG Scedular Answer:");
		while(ready.getNumberOfProcess() > 0) {
			
			if(currentProcess == null) {
				currentProcess = ready.getProcess(0);
			}

			tempTimer = 0;
			double Quantum =  Math.ceil(currentProcess.getQuantum()/4);
			Timer+=Quantum;
			tempTimer += Quantum;
			
			
			//update currentProcess
			currentProcess = update(currentProcess , Quantum);
			
			 
			// shift to remove
			 if(currentProcess.getBurstTime() <= 0) {
		            ready = RemoveProscess(ready , currentProcess , Timer);
		            currentProcess = null;
				}
			 
			 
			 if(currentProcess != null) {
				 // to check is new process Arrival ?
				 
					if((i+1) < queue.getNumberOfProcess()) {
						if(Timer >= queue.getProcess(i+1).getArrivalTime()) {
							
							++i;
							ready.addProcess(queue.getProcess(i));
						}
					}
			 }

			if (currentProcess != null && isHighPriority(ready , currentProcess.getPriority()) == 0 ) {
				Timer+=Quantum;
				tempTimer += Quantum;
				
				//update currentProcess
				currentProcess = update(currentProcess , Quantum);
				
				
				// shift to remove
				 if(currentProcess.getBurstTime() <= 0) {
			            ready = RemoveProscess(ready , currentProcess , Timer);
			            currentProcess = null;
					}
				
				if(currentProcess != null) {
					
					// to check is new process Arrival ?
					if((i+1) < queue.getNumberOfProcess()) {
						if(Timer >= queue.getProcess(i+1).getArrivalTime()) {
							
							++i;
							ready.addProcess(queue.getProcess(i));
						}
					}
					
				}
				
				
				if(currentProcess != null && isMiniBurst(ready, currentProcess.getBurstTime()) == 0) {
					Timer+=Quantum;
					tempTimer += Quantum;
					
					//update currentProcess
					currentProcess = update(currentProcess , Quantum);
					
					// shift to remove
					 if(currentProcess.getBurstTime() <= 0) {
				            ready = RemoveProscess(ready , currentProcess , Timer);
				            currentProcess = null;
						}
							

					if(currentProcess != null) {
						// to check is new process Arrival ?
						
						if((i+1) < queue.getNumberOfProcess()) {
							if(Timer >= queue.getProcess(i+1).getArrivalTime()) {
								
								++i;
								ready.addProcess(queue.getProcess(i));
							}
						}
				
					}
					
					
					}
					
				// back to  Burst
				
				else if(currentProcess != null) {
					System.out.println("|" + currentProcess.getName() + "|"+Timer + "  ");
					
					//update better Burst Time
					currentProcess = betterBurstTime(currentProcess, tempQuantum , tempTimer);
							
					// shift round
					ready = round(ready, currentProcess);
				
					// new currentPro
					int MiniBurst = isMiniBurst(ready, currentProcess.getBurstTime());
					currentProcess = ready.getProcess(MiniBurst);
				}

			}
			
			// back to better Priority
			
			else if(currentProcess != null) { 
				System.out.println("|" + currentProcess.getName() + "|" + Timer + "  ");
				
				//update better Priority
				currentProcess = betterPriority(currentProcess, tempQuantum, tempTimer);
			
				// shift round
				ready = round(ready, currentProcess);
				
				
				// new currentPro
				int highPriority = isHighPriority(ready , currentProcess.getPriority());
				currentProcess = ready.getProcess(highPriority);
			}
			
			
		}
		
	}
}
