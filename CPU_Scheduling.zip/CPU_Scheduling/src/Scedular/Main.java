package Scedular;

import java.util.Scanner;

public class Main {

	public static void main(String arg[]) {
		
	    // Non Primetive
		//  NonPrimetive Non = new NonPrimetive();
		//  Non.run();
		 
		// AG Scedular 
		//  Scedular AG = new Scedular();
		//  AG.run();
		// SJF s=new SJF();
		// s.run();
		
		System.err.println(" 1.SJF \n 2.RR \n 3.Priority \n 4.AG Scheduling \n 5.non-preemptive SJf ");
		System.err.print("Enter number of method that you want to apply :");
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		if(n==1){
			SJF sjf=new SJF();
			sjf.run();
		}
		else if (n==2){
			RR rr=new RR();
			rr.run();
		}
		else if(n==3){
			Priority pro=new Priority();
			pro.run();
		}
		else if(n==4){
			Schedular AG=new Schedular();
			AG.run();
		}
		else if (n==5){
			NonPrimetive non=new NonPrimetive();
			non.run();
		}


	}
}
