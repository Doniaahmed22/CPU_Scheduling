package Scedular;

public class ReadyQueue {
  private int NumberOfProcess = 0;
  private Process [] process;
  
  public ReadyQueue() {}
  public ReadyQueue(int NumberOfProcess) {
	  process = new Process[NumberOfProcess];
  }
  
  
  public void addProcess(Process process) {
	  if(NumberOfProcess <= this.process.length) {
		 this. process[NumberOfProcess] = process;
		 NumberOfProcess++;
	  }
	  
	  else {
		  System.out.println("\n\nQueue Is Full");
	  }
   }
  
  public void setNumberOfProcess(int NumberOfProcess) {
	  this.NumberOfProcess = NumberOfProcess;
  }
  
  public int getNumberOfProcess() {
	  return this.NumberOfProcess;
  }
  
  public void setProcess(Process process, int i) {
	  this.process[i] = process;
  }
  
  public Process getProcess(int i) {
	  return this.process[i];
  }
  
  public void sortArrival() {
	  
	  for(int i = 1 ; i < NumberOfProcess; i++) {
			
			for(int j = 1; j < NumberOfProcess - 1; j++) {
				
				if(process[j].getArrivalTime() > process[j+1].getArrivalTime()) {
				
				String swapName = process[j].getName();
				int swapBurst = process[j].getBurstTime();
				int swapArrival = process[j].getArrivalTime();
				
				process[j].setName(process[j+1].getName());
				process[j].setBurstTime(process[j+1].getBurstTime());
				process[j].setArrivalTime(process[j+1].getArrivalTime());
				
				process[j+1].setName(swapName);
				process[j+1].setBurstTime(swapBurst);
				process[j+1].setArrivalTime(swapArrival);
				}
				
			}
	    }
 }
 public void print(){
	// System.err.print("(");
	// for (int index = 0; index < NumberOfProcess; index++) {
	// 	if(index<NumberOfProcess-1){
	// 		System.out.print(process[index].getQuantum()+" , ");
	// 	}
		
	// }
	// System.err.println(")");
 }
  
}