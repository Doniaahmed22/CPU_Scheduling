package Scedular;

import java.nio.Buffer;
import java.util.*;
 
public class SJF {

    public SJF(){
        System.err.println("you choose Sjf");
    }

public void run (){
Scanner sc=new Scanner(System.in);
System.out.println ("enter no of process:");
int n= sc.nextInt();
int pid[] = new int[n]; 
int Arrival_Time[] = new int[n]; 
int burst_Time[] = new int[n]; 
int Complete_Time[] = new int[n]; 

int turnAround_Time[] = new int[n];
int Waiting_Time[] = new int[n];  
int check_ProcessComplete[] = new int[n];
int k[]= new int[n];  
    int i, st=0, tot=0;
    float Avarage_waiting=0, avgta=0;
    System.err.println("Enter Context swich :");
    Scanner context=new Scanner(System.in);
    int context_swich=context.nextInt();
 
    for (i=0;i<n;i++)
    {
     pid[i]= i+1;
     System.out.println ("enter process " +(i+1)+ " arrival time:");
     Arrival_Time[i]= sc.nextInt();
     System.out.println("enter process " +(i+1)+ " burst time:");
     burst_Time[i]= sc.nextInt();
     k[i]= burst_Time[i];
     check_ProcessComplete[i]= 0;
    }
    
    while(true){
     int min=99,c=n;
     if (tot==n)
     break;
    
     for ( i=0;i<n;i++)
     {
     if ((Arrival_Time[i]<=st) && (check_ProcessComplete[i]==0) && (burst_Time[i]<min))
     {
     min=burst_Time[i];
     c=i;
     }
     }
    
     if (c==n)
     {
     st+=context_swich;
     }
     else
     {
     burst_Time[c]--;
     st+=context_swich;
     if (burst_Time[c]==0)
     {
     Complete_Time[c]= st;
     check_ProcessComplete[c]=1;
     tot++;
     System.err.println("p"+(c+1)+" complete at time "+ Complete_Time[c]);
     }
     }
    }
    
    for(i=0;i<n;i++)
    {
     turnAround_Time[i] = Complete_Time[i] - Arrival_Time[i];
     Waiting_Time[i] = turnAround_Time[i] - k[i];
     Avarage_waiting+= Waiting_Time[i];
     avgta+= turnAround_Time[i];
    }
       
    System.out.println("pid  arrival  burst  complete turn waiting");
    for(i=0;i<n;i++)
    {
     System.out.println("p"+pid[i] +"\t"+ Arrival_Time[i]+"\t"+ k[i] +"\t"+ Complete_Time[i] +"\t" + turnAround_Time[i] +"\t"+ Waiting_Time[i]);
    }    
    System.out.println("\naverage tat is "+ (float)(avgta/n));
    System.out.println("average wt is "+ (float)(Avarage_waiting/n));
    sc.close();
}
}